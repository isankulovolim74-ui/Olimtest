package uz.olimtest

import android.content.Context
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException

object Cfg {
    const val TCP_PORT = 45454   // game traffic (JSON lines)
    const val UDP_PORT = 45455   // PIN discovery
    const val MIN_PLAYERS = 2    // set to 1 for solo testing
    const val MAX_PLAYERS = 50
}

object Net {
    private fun addr(i: Int): InetAddress = InetAddress.getByAddress(
        byteArrayOf(i.toByte(), (i shr 8).toByte(), (i shr 16).toByte(), (i shr 24).toByte()))

    @Suppress("DEPRECATION")
    private fun dhcp(ctx: Context) =
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).dhcpInfo

    /** On a phone hotspot the teacher's phone is the gateway. */
    fun gateway(ctx: Context): String? {
        val g = try { dhcp(ctx)?.gateway ?: 0 } catch (e: Exception) { 0 }
        return if (g != 0) addr(g).hostAddress else null
    }

    /** UDP broadcast "who has this PIN?" -> the teacher's phone answers with its IP. */
    fun discover(ctx: Context, pin: String): String? {
        try {
            val d = dhcp(ctx)
            val targets = arrayListOf(InetAddress.getByName("255.255.255.255"))
            if (d != null && d.ipAddress != 0) targets.add(addr((d.ipAddress and d.netmask) or d.netmask.inv()))
            if (d != null && d.gateway != 0) targets.add(addr(d.gateway))
            DatagramSocket().use { ds ->
                ds.broadcast = true
                ds.soTimeout = 700
                val msg = "OLIMTEST?$pin".toByteArray()
                repeat(3) {
                    targets.forEach { t -> try { ds.send(DatagramPacket(msg, msg.size, t, Cfg.UDP_PORT)) } catch (_: Exception) {} }
                    try {
                        val p = DatagramPacket(ByteArray(64), 64)
                        ds.receive(p)
                        if (String(p.data, 0, p.length) == "OLIMTEST!$pin") return p.address.hostAddress
                    } catch (_: SocketTimeoutException) {}
                }
            }
        } catch (_: Exception) {}
        return null
    }

    fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni -> ni.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .mapNotNull { it.hostAddress }
    } catch (_: Exception) { emptyList() }
}
