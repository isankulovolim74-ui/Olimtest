package uz.olimtest

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Question(val text: String, val options: List<String>, val correct: Int, val timeSec: Int)
data class Quiz(val id: String, val title: String, val questions: List<Question>)

/** Stores quizzes as JSON in SharedPreferences (offline, no database needed). */
class QuizStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("quizzes", Context.MODE_PRIVATE)

    fun all(): MutableList<Quiz> {
        val raw = sp.getString("data", null)
        if (raw == null) {
            val l = mutableListOf(sample()); write(l); return l
        }
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { parse(arr.getJSONObject(it)) }
    }

    fun save(q: Quiz) {
        val l = all()
        val i = l.indexOfFirst { it.id == q.id }
        if (i >= 0) l[i] = q else l.add(q)
        write(l)
    }

    fun delete(id: String) = write(all().filter { it.id != id })

    private fun write(l: List<Quiz>) {
        val arr = JSONArray()
        l.forEach { arr.put(toJson(it)) }
        sp.edit().putString("data", arr.toString()).apply()
    }

    private fun toJson(q: Quiz) = JSONObject().put("id", q.id).put("title", q.title).put(
        "questions", JSONArray().also { a ->
            q.questions.forEach {
                a.put(JSONObject().put("text", it.text).put("options", JSONArray(it.options))
                    .put("correct", it.correct).put("time", it.timeSec))
            }
        })

    private fun parse(o: JSONObject): Quiz {
        val qa = o.getJSONArray("questions")
        return Quiz(o.getString("id"), o.getString("title"), List(qa.length()) { i ->
            val q = qa.getJSONObject(i)
            val oa = q.getJSONArray("options")
            Question(q.getString("text"), List(oa.length()) { oa.getString(it) }, q.getInt("correct"), q.getInt("time"))
        })
    }

    private fun sample() = Quiz("sample", "Namuna / Намуна", listOf(
        Question("O'zbekistonning poytaxti qaysi shahar?", listOf("Toshkent", "Samarqand", "Buxoro", "Xiva"), 0, 15),
        Question("2 + 2 × 2 = ?", listOf("8", "6", "4", "10"), 1, 15),
        Question("Quyoshdan uchinchi sayyora qaysi?", listOf("Mars", "Venera", "Yer", "Yupiter"), 2, 20),
        Question("Пойтахти Тоҷикистон кадом шаҳр аст?", listOf("Душанбе", "Хуҷанд", "Бохтар", "Кӯлоб"), 0, 15)
    ))
}
