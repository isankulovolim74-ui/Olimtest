package uz.olimtest

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

object C {
    val BLUE = 0xFF0B2E6F.toInt()
    val BLUE2 = 0xFF1B4FBF.toInt()
    val GOLD = 0xFFF5B301.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val LIGHT = 0xFFE8EFFC.toInt()
    val RED = 0xFFC62828.toInt()
    val OPT = intArrayOf(0xFF1B4FBF.toInt(), 0xFFD99A00.toInt(), 0xFF0A2A66.toInt(), 0xFF2F8FD8.toInt())
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun Context.lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

fun Context.shape(color: Int, r: Int = 16, strokeColor: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
    if (strokeColor != 0) setStroke(dp(2), strokeColor)
}

fun Context.label(s: String, size: Float = 16f, color: Int = C.WHITE, bold: Boolean = false, center: Boolean = false) =
    TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        if (center) gravity = Gravity.CENTER
    }

fun Context.button(s: String, bg: Int = C.GOLD, fg: Int = C.BLUE, onClick: () -> Unit) = Button(this).apply {
    text = s; isAllCaps = false; textSize = 17f; setTextColor(fg); stateListAnimator = null
    background = shape(bg, 14); setPadding(dp(12), dp(14), dp(12), dp(14))
    setOnClickListener { onClick() }
}

fun Context.input(h: String, value: String = "", number: Boolean = false) = EditText(this).apply {
    setHint(h); setText(value); textSize = 17f
    setTextColor(C.BLUE); setHintTextColor(0xFF8A9AB8.toInt())
    background = shape(C.WHITE, 12, C.LIGHT)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    if (number) inputType = InputType.TYPE_CLASS_NUMBER
}

fun Context.card() = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = shape(C.WHITE, 18)
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

fun Context.row(vararg v: View) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    v.forEach { addView(it, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4); marginStart = dp(4) }) }
}

fun Context.screen(build: LinearLayout.() -> Unit): View {
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(24), dp(20), dp(28))
        build()
    }
    return ScrollView(this).apply {
        setBackgroundColor(C.BLUE); isFillViewport = true
        addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
    }
}

fun LinearLayout.add(v: View, top: Int = 12) = addView(v, context.lp(top))

fun Context.optionBox(i: Int, s: String, alpha: Float = 1f, suffix: String = ""): TextView =
    label("${"ABCD"[i]}   $s$suffix", 18f, C.WHITE, true).apply {
        background = shape(C.OPT[i], 14)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        this.alpha = alpha
    }

fun Context.board(rows: List<Pair<String, Int>>): LinearLayout = card().apply {
    rows.forEachIndexed { i, (n, s) ->
        val line = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        line.addView(label("${i + 1}", 18f, if (i == 0) 0xFFD99A00.toInt() else C.BLUE, true), LinearLayout.LayoutParams(dp(36), WRAP))
        line.addView(label(n, 18f, C.BLUE, i == 0), LinearLayout.LayoutParams(0, WRAP, 1f))
        line.addView(label("$s", 18f, C.BLUE2, true))
        addView(line)
    }
}
