package uz.olimtest

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

/** Single-activity app; screens are built in code (no XML layouts) and swapped with setScreen(). */
class MainActivity : Activity() {
    private lateinit var store: QuizStore
    private var host: GameHost? = null
    private var client: GameClient? = null
    private var back: (() -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())

    // student-side state
    private var qMsg: JSONObject? = null
    private var qEndAt = 0L
    private var myAnswer = -1
    private var lobbyCount = 0
    private var studentEnded = false
    private var timerView: TextView? = null
    private val ticker = object : Runnable {
        override fun run() {
            val left = ((qEndAt - SystemClock.elapsedRealtime() + 999) / 1000).toInt().coerceAtLeast(0)
            timerView?.text = "$left"
            ui.postDelayed(this, 250)
        }
    }

    private fun t(k: String) = I18n.t(k)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        store = QuizStore(this)
        I18n.lang = getSharedPreferences("olimtest", MODE_PRIVATE).getString("lang", "uz") ?: "uz"
        home()
    }

    private fun setScreen(v: View, onBack: (() -> Unit)? = null) { setContentView(v); back = onBack }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { val b = back; if (b != null) b() else super.onBackPressed() }

    override fun onDestroy() { leave(); super.onDestroy() }

    private fun leave() {
        ui.removeCallbacks(ticker)
        host?.stop(); host = null
        client?.close(); client = null
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton(t("yes")) { _, _ -> yes() }.setNegativeButton(t("no"), null).show()
    }

    // ===================== HOME =====================
    private fun home() {
        leave()
        setScreen(screen {
            add(label("★", 56f, C.GOLD, true, true), 24)
            add(label("Olimtest", 42f, C.GOLD, true, true), 0)
            add(label(t("tagline"), 16f, C.WHITE, false, true), 4)
            add(button(t("teacher")) { teacherHome() }, 48)
            add(button(t("student"), C.WHITE) { joinScreen() }, 14)
            val uz = I18n.lang == "uz"
            add(row(
                button("O'zbekcha", if (uz) C.GOLD else C.BLUE2, if (uz) C.BLUE else C.WHITE) { setLang("uz") },
                button("Тоҷикӣ", if (!uz) C.GOLD else C.BLUE2, if (!uz) C.BLUE else C.WHITE) { setLang("tg") }
            ), 40)
        })
    }

    private fun setLang(l: String) {
        I18n.lang = l
        getSharedPreferences("olimtest", MODE_PRIVATE).edit().putString("lang", l).apply()
        home()
    }

    // ===================== TEACHER: quiz list & editor =====================
    private fun teacherHome() {
        leave()
        val quizzes = store.all()
        setScreen(screen {
            add(label(t("my_quizzes"), 26f, C.GOLD, true), 0)
            if (quizzes.isEmpty()) add(label(t("quiz_empty")), 16)
            quizzes.forEach { q ->
                val c = card()
                c.addView(label(q.title, 20f, C.BLUE, true))
                c.addView(label("${q.questions.size} ${t("questions")}", 14f, C.BLUE2), lp(2))
                c.addView(row(
                    button(t("host")) { startHost(q) }.apply { textSize = 14f },
                    button(t("edit"), C.LIGHT) { editor(q) }.apply { textSize = 14f },
                    button(t("delete"), C.LIGHT, C.RED) {
                        confirm(t("delete_confirm")) { store.delete(q.id); teacherHome() }
                    }.apply { textSize = 14f }
                ), lp(10))
                add(c, 12)
            }
            add(button(t("new_quiz")) { editor(null) }, 16)
            add(button(t("back"), C.BLUE2, C.WHITE) { home() }, 10)
        }, onBack = { home() })
    }

    private class QH(val text: EditText, val opts: List<EditText>, val radios: List<RadioButton>, val time: EditText)

    private fun editor(src: Quiz?) {
        val holders = mutableListOf<QH>()
        val titleEt = input(t("quiz_title"), src?.title ?: "")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun addQ(q: Question?) {
            val c = card()
            val text = input(t("question_text"), q?.text ?: "")
            c.addView(text)
            val opts = ArrayList<EditText>()
            val radios = ArrayList<RadioButton>()
            for (i in 0 until 4) {
                val r = RadioButton(this).apply { isChecked = (q?.correct ?: 0) == i }
                val e = input("${t("option")} ${"ABCD"[i]}", q?.options?.getOrNull(i) ?: "")
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
                line.addView(r)
                line.addView(e, LinearLayout.LayoutParams(0, WRAP, 1f))
                c.addView(line, lp(6))
                opts.add(e); radios.add(r)
            }
            radios.forEach { r -> r.setOnClickListener { radios.forEach { it.isChecked = false }; r.isChecked = true } }
            val time = input(t("time_sec"), (q?.timeSec ?: 20).toString(), true)
            c.addView(time, lp(6))
            val h = QH(text, opts, radios, time)
            holders.add(h)
            c.addView(button(t("remove"), C.LIGHT, C.RED) { list.removeView(c); holders.remove(h) }, lp(8))
            list.addView(c, lp(12))
        }

        if (src == null || src.questions.isEmpty()) addQ(null) else src.questions.forEach { addQ(it) }

        fun save() {
            val title = titleEt.text.toString().trim()
            val qs = ArrayList<Question>()
            var ok = title.isNotEmpty() && holders.isNotEmpty()
            for (h in holders) {
                if (!ok) break
                val txt = h.text.text.toString().trim()
                val chosen = h.radios.indexOfFirst { it.isChecked }
                val opts = ArrayList<String>()
                var correct = -1
                h.opts.forEachIndexed { i, e ->
                    val s = e.text.toString().trim()
                    if (s.isNotEmpty()) { if (i == chosen) correct = opts.size; opts.add(s) }
                }
                val tm = (h.time.text.toString().toIntOrNull() ?: 20).coerceIn(5, 120)
                if (txt.isEmpty() || opts.size < 2 || correct < 0) ok = false else qs.add(Question(txt, opts, correct, tm))
            }
            if (!ok) { toast(t("invalid_quiz")); return }
            store.save(Quiz(src?.id ?: System.currentTimeMillis().toString(), title, qs))
            teacherHome()
        }

        setScreen(screen {
            add(label(t("my_quizzes"), 24f, C.GOLD, true), 0)
            add(titleEt, 12)
            add(list, 0)
            add(button(t("add_question"), C.WHITE) { addQ(null) }, 14)
            add(button(t("save")) { save() }, 12)
            add(button(t("cancel"), C.BLUE2, C.WHITE) { teacherHome() }, 10)
        }, onBack = { teacherHome() })
    }

    // ===================== TEACHER: live game =====================
    private fun startHost(q: Quiz) {
        leave()
        val h = GameHost(q) { renderHost() }
        host = h
        h.start()
        renderHost()
    }

    private fun renderHost() {
        val h = host ?: return
        when (h.state) {
            State.LOBBY -> hostLobby(h)
            State.QUESTION -> hostQuestion(h)
            State.REVEAL -> hostReveal(h)
            State.ENDED -> hostEnd(h)
        }
    }

    private fun confirmEnd() = confirm(t("end_game")) { teacherHome() }

    private fun hostLobby(h: GameHost) = setScreen(screen {
        add(label(t("pin"), 16f, C.WHITE, false, true), 8)
        val pc = card(); pc.addView(label(h.pin, 52f, C.BLUE, true, true)); add(pc, 6)
        add(label(t("join_hint"), 14f, C.WHITE, false, true), 10)
        val ips = Net.localIps()
        add(label("${t("host_ip")}: ${if (ips.isEmpty()) "—" else ips.joinToString(" / ")}", 15f, C.GOLD, true, true), 6)
        if (h.bindError) add(label(t("err_port"), 15f, 0xFFFF8A80.toInt(), true, true), 8)
        add(label("${t("players")}: ${h.playerCount()}/${Cfg.MAX_PLAYERS}", 20f, C.WHITE, true), 20)
        val names = h.playerNames()
        add(label(if (names.isEmpty()) "…" else names.joinToString("  •  "), 16f), 6)
        add(button(t("start")) { if (h.playerCount() < Cfg.MIN_PLAYERS) toast(t("need_players")) else h.next() }, 24)
        add(button(t("back"), C.BLUE2, C.WHITE) { confirmEnd() }, 10)
    }, onBack = { confirmEnd() })

    private fun hostQuestion(h: GameHost) = setScreen(screen {
        val q = h.question()
        add(label("${t("question_of")} ${h.qIndex + 1}/${h.quiz.questions.size}", 16f, C.GOLD, true, true), 0)
        add(label("${h.remaining()}", 56f, C.WHITE, true, true), 4)
        val qc = card(); qc.addView(label(q.text, 22f, C.BLUE, true, true)); add(qc, 8)
        q.options.forEachIndexed { i, o -> add(optionBox(i, o), 8) }
        add(label("${t("answered")}: ${h.answeredCount()}/${h.connectedCount()}", 16f, C.WHITE, false, true), 14)
        add(button(t("show_results")) { h.revealNow() }, 12)
    }, onBack = { confirmEnd() })

    private fun hostReveal(h: GameHost) = setScreen(screen {
        val q = h.question()
        val last = h.qIndex == h.quiz.questions.size - 1
        val qc = card(); qc.addView(label(q.text, 20f, C.BLUE, true, true)); add(qc, 0)
        q.options.forEachIndexed { i, o ->
            val c = h.counts.getOrElse(i) { 0 }
            add(optionBox(i, o, if (i == q.correct) 1f else 0.4f, "    ·  $c" + if (i == q.correct) "   ✓" else ""), 8)
        }
        add(label(t("leaderboard"), 22f, C.GOLD, true), 18)
        add(board(h.top(5)), 6)
        add(button(if (last) t("finish") else t("next")) { h.next() }, 16)
    }, onBack = { confirmEnd() })

    private fun hostEnd(h: GameHost) = setScreen(screen {
        add(label("🏆", 56f, C.GOLD, true, true), 8)
        add(label(t("final_results"), 26f, C.GOLD, true, true), 4)
        add(board(h.top(10)), 16)
        add(button(t("close")) { teacherHome() }, 20)
    }, onBack = { teacherHome() })

    // ===================== STUDENT =====================
    private fun joinScreen(err: String? = null) {
        leave()
        studentEnded = false
        val pin = input(t("pin"), "", true)
        val name = input(t("your_name"))
        val ip = input(t("host_ip_opt"))
        val status = label(err ?: "", 15f, C.GOLD, true, true)
        setScreen(screen {
            add(label(t("student"), 26f, C.GOLD, true), 0)
            add(label(t("join_hint"), 14f), 8)
            add(pin, 16); add(name, 10); add(ip, 10); add(status, 10)
            add(button(t("join")) { doJoin(pin.text.toString().trim(), name.text.toString().trim(), ip.text.toString().trim(), status) }, 16)
            add(button(t("back"), C.BLUE2, C.WHITE) { home() }, 10)
        }, onBack = { home() })
    }

    private fun doJoin(pin: String, name: String, ip: String, status: TextView) {
        if (pin.length != 6 || name.isEmpty()) { status.text = t("fill_fields"); return }
        status.text = t("connecting")
        myAnswer = -1; lobbyCount = 0
        val c = GameClient({ onClientMsg(it) }, { onClientClosed() })
        client = c
        c.connect(this, pin, name, ip) { joinScreen(t("err_conn")) }
    }

    private fun onClientMsg(m: JSONObject) {
        when (m.optString("t")) {
            "error" -> joinScreen(t(when (m.optString("code")) {
                "pin" -> "err_pin"; "started" -> "err_started"; "full" -> "err_full"; else -> "err_name"
            }))
            "joined" -> studentWait()
            "lobby" -> { lobbyCount = m.optInt("n"); if (!studentInGame) studentWait() }
            "question" -> {
                studentInGame = true
                qMsg = m; myAnswer = -1
                qEndAt = SystemClock.elapsedRealtime() + m.getInt("time") * 1000L
                studentQuestion()
            }
            "reveal" -> { ui.removeCallbacks(ticker); studentReveal(m) }
            "end" -> { ui.removeCallbacks(ticker); studentEnded = true; studentEnd(m) }
        }
    }
    private var studentInGame = false

    private fun onClientClosed() {
        if (client == null || studentEnded) return
        toast(t("disconnected")); home()
    }

    private fun confirmLeave() = confirm(t("leave_confirm")) { home() }

    private fun studentWait() {
        studentInGame = false; qMsg = null
        setScreen(screen {
            add(label("✓", 72f, C.GOLD, true, true), 40)
            add(label(t("waiting"), 20f, C.WHITE, true, true), 10)
            add(label("${t("players")}: $lobbyCount", 16f, C.GOLD, false, true), 14)
        }, onBack = { confirmLeave() })
    }

    private fun studentQuestion() {
        val m = qMsg ?: return
        val opts = m.getJSONArray("options")
        setScreen(screen {
            add(label("${m.getInt("idx") + 1}/${m.getInt("total")}", 16f, C.GOLD, true, true), 0)
            val tv = label("0", 48f, C.WHITE, true, true); timerView = tv; add(tv, 4)
            val qc = card(); qc.addView(label(m.getString("text"), 20f, C.BLUE, true, true)); add(qc, 8)
            for (i in 0 until opts.length()) {
                val v = optionBox(i, opts.getString(i), if (myAnswer >= 0 && myAnswer != i) 0.4f else 1f, if (myAnswer == i) "   ●" else "")
                v.setOnClickListener { answer(i) }
                add(v, 8)
            }
            if (myAnswer >= 0) add(label(t("answer_sent"), 16f, C.GOLD, true, true), 14)
        }, onBack = { confirmLeave() })
        ui.removeCallbacks(ticker); ui.post(ticker)
    }

    private fun answer(i: Int) {
        val m = qMsg ?: return
        if (myAnswer >= 0 || SystemClock.elapsedRealtime() >= qEndAt) return
        myAnswer = i
        client?.send(JSONObject().put("t", "answer").put("q", m.getInt("idx")).put("a", i))
        studentQuestion()
    }

    private fun parseTop(a: JSONArray) = List(a.length()) { a.getJSONObject(it).let { o -> o.getString("n") to o.getInt("s") } }

    private fun studentReveal(m: JSONObject) {
        val got = m.getBoolean("got")
        val answered = myAnswer >= 0
        setScreen(screen {
            add(label(if (got) "✓" else if (answered) "✗" else "⏱", 72f, if (got) C.GOLD else C.WHITE, true, true), 10)
            add(label(if (got) t("correct") else if (answered) t("wrong") else t("timeout"), 28f, C.WHITE, true, true), 0)
            add(label("+${m.getInt("delta")}", 24f, C.GOLD, true, true), 6)
            add(label("${t("total")}: ${m.getInt("score")}    ${t("rank")}: ${m.getInt("rank")}", 18f, C.WHITE, true, true), 8)
            add(label(t("leaderboard"), 20f, C.GOLD, true), 18)
            add(board(parseTop(m.getJSONArray("top"))), 6)
            add(label(t("wait_next"), 14f, C.WHITE, false, true), 14)
        }, onBack = { confirmLeave() })
    }

    private fun studentEnd(m: JSONObject) = setScreen(screen {
        add(label("🏆", 56f, C.GOLD, true, true), 8)
        add(label(t("final_results"), 26f, C.GOLD, true, true), 4)
        add(label("${t("rank")}: ${m.getInt("rank")}    ${t("total")}: ${m.getInt("score")}", 20f, C.WHITE, true, true), 8)
        add(board(parseTop(m.getJSONArray("top"))), 16)
        add(button(t("close")) { home() }, 20)
    }, onBack = { home() })
}
