package uz.olimtest

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** The student's phone. Callbacks are always delivered on the main thread. */
class GameClient(private val onMsg: (JSONObject) -> Unit, private val onClosed: () -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var closing = false
    private var socket: Socket? = null
    private var out: BufferedWriter? = null

    fun connect(ctx: Context, pin: String, name: String, manualIp: String, onFail: () -> Unit) {
        thread(isDaemon = true) {
            val s = Socket()
            try {
                val ip = if (manualIp.isNotEmpty()) manualIp
                else (Net.discover(ctx, pin) ?: Net.gateway(ctx) ?: throw IOException("no host"))
                s.connect(InetSocketAddress(ip, Cfg.TCP_PORT), 3000)
                s.tcpNoDelay = true
                socket = s
                out = s.getOutputStream().bufferedWriter(Charsets.UTF_8)
                send(JSONObject().put("t", "join").put("pin", pin).put("name", name))
            } catch (e: Exception) {
                try { s.close() } catch (_: Exception) {}
                main.post { if (!closing) onFail() }
                return@thread
            }
            try {
                val r = s.getInputStream().bufferedReader(Charsets.UTF_8)
                while (true) {
                    val line = r.readLine() ?: break
                    val m = JSONObject(line)
                    main.post { if (!closing) onMsg(m) }
                }
            } catch (_: Exception) {}
            main.post { if (!closing) onClosed() }
        }
    }

    fun send(m: JSONObject) {
        val line = m.toString() + "\n"
        try { io.execute { try { out?.write(line); out?.flush() } catch (_: Exception) {} } } catch (_: Exception) {}
    }

    fun close() {
        closing = true
        try { socket?.close() } catch (_: Exception) {}
        io.shutdownNow()
    }
}
