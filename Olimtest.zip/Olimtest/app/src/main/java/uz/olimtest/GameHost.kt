package uz.olimtest

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import java.util.concurrent.Executors
import kotlin.concurrent.thread

enum class State { LOBBY, QUESTION, REVEAL, ENDED }

class Player(val id: Int, val name: String, val socket: Socket) {
    val out: BufferedWriter = socket.getOutputStream().bufferedWriter(Charsets.UTF_8)
    var score = 0
    var delta = 0
    var got = false
    var answer = -1
    var answerMs = 0L
    @Volatile var connected = true
}

/**
 * The teacher's phone: authoritative game server.
 * Protocol = one JSON object per line over TCP (see README).
 * All state changes are synchronized on this object; the UI is notified on the main thread.
 */
class GameHost(val quiz: Quiz, private val onUpdate: () -> Unit) {
    val pin: String = (100000..999999).random().toString()

    @Volatile var state = State.LOBBY
        private set
    var qIndex = -1
        private set
    var counts = IntArray(4)
        private set
    @Volatile var bindError = false
        private set

    private var startAt = 0L
    private var endAt = 0L
    private var nextId = 1
    private val players = LinkedHashMap<Int, Player>()
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()   // all socket writes happen here
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var udp: DatagramSocket? = null

    // ---------- lifecycle ----------
    fun start() {
        running = true
        thread(isDaemon = true) {
            try {
                val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(Cfg.TCP_PORT)) }
                server = ss
                while (running) {
                    val s = ss.accept()
                    s.tcpNoDelay = true
                    thread(isDaemon = true) { handle(s) }
                }
            } catch (e: Exception) {
                if (running) { bindError = true; notifyUi() }
            }
        }
        thread(isDaemon = true) {
            try {
                val ds = DatagramSocket(null as SocketAddress?).apply {
                    reuseAddress = true; broadcast = true; bind(InetSocketAddress(Cfg.UDP_PORT))
                }
                udp = ds
                val buf = ByteArray(128)
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    ds.receive(p)
                    if (String(p.data, 0, p.length) == "OLIMTEST?$pin") {
                        val r = "OLIMTEST!$pin".toByteArray()
                        ds.send(DatagramPacket(r, r.size, p.address, p.port))
                    }
                }
            } catch (_: Exception) {}
        }
    }

    fun stop() {
        running = false
        main.removeCallbacks(tick)
        try { server?.close() } catch (_: Exception) {}
        try { udp?.close() } catch (_: Exception) {}
        synchronized(this) { players.values.forEach { try { it.socket.close() } catch (_: Exception) {} } }
        io.shutdownNow()
    }

    // ---------- connection handling (runs on per-client threads) ----------
    private fun handle(s: Socket) {
        var me: Player? = null
        try {
            val r = s.getInputStream().bufferedReader(Charsets.UTF_8)
            while (true) {
                val line = r.readLine() ?: break
                val m = JSONObject(line)
                when (m.optString("t")) {
                    "join" -> { me = join(s, m); if (me == null) break }
                    "answer" -> me?.let { answer(it, m.optInt("q", -1), m.optInt("a", -1)) }
                }
            }
        } catch (_: Exception) {
        } finally {
            me?.let { leave(it) }
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun join(s: Socket, m: JSONObject): Player? {
        val name = m.optString("name").trim().take(20)
        var err: String? = null
        var p: Player? = null
        synchronized(this) {
            err = when {
                m.optString("pin") != pin -> "pin"
                state != State.LOBBY -> "started"
                players.size >= Cfg.MAX_PLAYERS -> "full"
                name.isEmpty() || players.values.any { it.name.equals(name, true) } -> "name"
                else -> null
            }
            if (err == null) { p = Player(nextId++, name, s); players[p!!.id] = p!! }
        }
        if (err != null) {
            try {
                s.getOutputStream().write((JSONObject().put("t", "error").put("code", err).toString() + "\n").toByteArray())
                s.getOutputStream().flush()
            } catch (_: Exception) {}
            return null
        }
        send(p!!, JSONObject().put("t", "joined").put("id", p!!.id))
        synchronized(this) { broadcastLobby() }
        notifyUi()
        return p
    }

    @Synchronized private fun leave(p: Player) {
        p.connected = false
        if (state == State.LOBBY) { players.remove(p.id); broadcastLobby() }
        else if (state == State.QUESTION && allAnswered()) reveal()
        notifyUi()
    }

    @Synchronized private fun answer(p: Player, q: Int, a: Int) {
        if (state != State.QUESTION || q != qIndex || p.answer >= 0 || a !in question().options.indices) return
        p.answer = a
        p.answerMs = SystemClock.elapsedRealtime() - startAt
        if (allAnswered()) reveal() else notifyUi()
    }

    // ---------- teacher controls ----------
    @Synchronized fun next() {
        when (state) {
            State.LOBBY -> if (connectedCount() >= Cfg.MIN_PLAYERS) advance()
            State.REVEAL -> advance()
            else -> {}
        }
    }

    @Synchronized fun revealNow() { if (state == State.QUESTION) reveal() }

    private fun advance() {
        qIndex++
        if (qIndex >= quiz.questions.size) finish() else ask()
    }

    private fun ask() {
        val q = question()
        players.values.forEach { it.answer = -1; it.answerMs = 0 }
        state = State.QUESTION
        startAt = SystemClock.elapsedRealtime()
        endAt = startAt + q.timeSec * 1000L
        broadcast(JSONObject().put("t", "question").put("idx", qIndex).put("total", quiz.questions.size)
            .put("text", q.text).put("options", JSONArray(q.options)).put("time", q.timeSec))
        main.removeCallbacks(tick)
        main.postDelayed(tick, 500)
        notifyUi()
    }

    /** Kahoot-style scoring: correct = 500..1000 points, faster = more. */
    private fun reveal() {
        state = State.REVEAL
        main.removeCallbacks(tick)
        val q = question()
        val limit = q.timeSec * 1000.0
        counts = IntArray(q.options.size)
        for (p in players.values) {
            p.got = false; p.delta = 0
            if (p.answer in counts.indices) {
                counts[p.answer]++
                if (p.answer == q.correct) {
                    p.got = true
                    p.delta = (1000 * (1 - (p.answerMs / limit).coerceIn(0.0, 1.0) / 2)).toInt()
                    p.score += p.delta
                }
            }
        }
        val top = topJson(5)
        ranking().forEachIndexed { i, p ->
            if (p.connected) send(p, JSONObject().put("t", "reveal").put("correct", q.correct).put("got", p.got)
                .put("delta", p.delta).put("score", p.score).put("rank", i + 1).put("top", top)
                .put("counts", JSONArray(counts.toList())))
        }
        notifyUi()
    }

    private fun finish() {
        state = State.ENDED
        main.removeCallbacks(tick)
        val top = topJson(10)
        ranking().forEachIndexed { i, p ->
            if (p.connected) send(p, JSONObject().put("t", "end").put("score", p.score).put("rank", i + 1).put("top", top))
        }
        notifyUi()
    }

    private val tick = object : Runnable {
        override fun run() {
            synchronized(this@GameHost) {
                if (state != State.QUESTION) return
                if (SystemClock.elapsedRealtime() >= endAt) { reveal(); return }
            }
            notifyUi()
            main.postDelayed(this, 500)
        }
    }

    // ---------- read-only helpers for the UI ----------
    fun question() = quiz.questions[qIndex]
    fun remaining() = ((endAt - SystemClock.elapsedRealtime() + 999) / 1000).toInt().coerceAtLeast(0)
    @Synchronized fun playerCount() = players.values.count { it.connected }
    fun connectedCount() = playerCount()
    @Synchronized fun answeredCount() = players.values.count { it.connected && it.answer >= 0 }
    @Synchronized fun playerNames() = players.values.filter { it.connected }.map { it.name }
    @Synchronized fun top(n: Int) = ranking().take(n).map { it.name to it.score }

    private fun ranking() = players.values.sortedByDescending { it.score }
    private fun topJson(n: Int) = JSONArray().also { a ->
        ranking().take(n).forEach { a.put(JSONObject().put("n", it.name).put("s", it.score)) }
    }
    private fun allAnswered(): Boolean {
        val c = players.values.filter { it.connected }
        return c.isNotEmpty() && c.all { it.answer >= 0 }
    }
    private fun broadcastLobby() {
        broadcast(JSONObject().put("t", "lobby").put("n", players.values.count { it.connected }))
    }
    private fun broadcast(m: JSONObject) { players.values.filter { it.connected }.forEach { send(it, m) } }
    private fun send(p: Player, m: JSONObject) {
        val line = m.toString() + "\n"
        try {
            io.execute { try { p.out.write(line); p.out.flush() } catch (_: Exception) { p.connected = false } }
        } catch (_: Exception) {}
    }
    private fun notifyUi() { main.post { onUpdate() } }
}
