# Olimtest — offline Kahoot-style quiz (Uzbek / Tajik)

Kotlin, plain Android SDK (no third-party libraries), minSdk 24. Works with **no internet**:
the teacher's phone is the game server, students join over its Wi-Fi hotspot.

## Architecture

```
 Teacher phone (host)                         Student phones (2–50)
 ┌──────────────────────┐   TCP :45454       ┌────────────────────┐
 │ MainActivity (UI)    │◄──JSON lines──────►│ MainActivity (UI)  │
 │ GameHost  (engine)   │   UDP :45455       │ GameClient         │
 │  ├ TCP ServerSocket  │◄──PIN discovery────│  └ Net.discover()  │
 │  ├ UDP responder     │                    └────────────────────┘
 │  ├ state machine     │
 │  └ scoring/ranking   │
 └──────────────────────┘
```

| File | Role |
|---|---|
| `Models.kt` | `Quiz`, `Question`, `QuizStore` (JSON in SharedPreferences, sample quiz seeded) |
| `GameHost.kt` | Authoritative server: lobby → question → reveal → … → end; timer; scoring; leaderboard |
| `GameClient.kt` | Student socket; delivers messages on the main thread |
| `Net.kt` | Ports/limits (`Cfg`), UDP PIN discovery, gateway lookup, local IP listing |
| `I18n.kt` | Uzbek (Latin) + Tajik (Cyrillic) strings, switchable at runtime |
| `Ui.kt`, `MainActivity.kt` | Blue/white/gold UI built in code; all screens |

**Join flow.** Student enters PIN + name. The app (1) uses the optional IP if typed, otherwise
(2) broadcasts `OLIMTEST?<pin>` over UDP and the host replies `OLIMTEST!<pin>`, otherwise
(3) falls back to the Wi-Fi gateway IP (= the teacher's phone when it is the hotspot). Then it opens TCP and sends `join`.

**Game state machine (host).** `LOBBY → QUESTION → REVEAL → (QUESTION …) → ENDED`.
Teacher presses Start / Show results / Next. A question also ends automatically when time runs out
or every connected player has answered.

**Scoring.** Wrong/no answer = 0. Correct = `1000 × (1 − 0.5 × elapsed/limit)` → 500…1000 points.
Elapsed time is measured on the host clock (no client clock trust).

**Protocol** (one JSON object per line):
- client→host: `{t:"join",pin,name}`, `{t:"answer",q,a}`
- host→client: `joined`, `error{code: pin|started|full|name}`, `lobby{n}`, `question{idx,total,text,options,time}`,
  `reveal{correct,got,delta,score,rank,top,counts}`, `end{score,rank,top}`

## Build the APK

**Android Studio (easiest):** File ▸ Open ▸ select the `Olimtest` folder → wait for Gradle sync
(needs internet once to download Android Gradle Plugin) → **Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)**.
Output: `app/build/outputs/apk/debug/app-debug.apk`. Copy to phones and install (allow "unknown sources").

**Command line** (JDK 17 + Android SDK installed, `ANDROID_HOME` set):
```
gradle wrapper --gradle-version 8.7     # once, creates ./gradlew
./gradlew assembleDebug
```
For a signed release APK use Build ▸ Generate Signed Bundle / APK.

## How to test

1. Install on 2+ phones (teacher + students). Solo test: set `MIN_PLAYERS = 1` in `Net.kt`.
2. Teacher phone: turn on **Wi-Fi hotspot**. Student phones: connect to it (ignore "no internet" warnings;
   if connection fails, turn off mobile data on students).
3. Teacher: Olimtest ▸ Teacher ▸ **O'ynash / Бозӣ** on the sample quiz. A 6-digit PIN and the host IP appear.
4. Students: Student ▸ enter PIN + name ▸ Join. Names appear live in the teacher's lobby.
5. Teacher: **Start**. Check: timer counts down on all phones; students answer; "answered x/n" rises;
   when all answered (or time ends) everyone sees ✓/✗, points, rank and top‑5.
6. Verify scoring: a fast correct answer ≈ 900+, a late correct answer ≈ 500–600, wrong = 0.
7. Edge cases: wrong PIN → error; join after start → "already started"; duplicate name → rejected;
   51st player → "full"; student closes app mid-game → game continues; **Next** until the final podium.
8. Switch O'zbekcha / Тоҷикӣ on the home screen and re-check every screen.
9. Create your own quiz: Teacher ▸ + Yangi test ▸ fill question, options, tick the correct radio, set seconds ▸ Save.

## Known limits (v0.1) / next steps
- Host game lives in the Activity: keep the teacher app in the foreground (screen stays on). Next: foreground service.
- No reconnect after a student drops; no image questions; no results export.
- If the router/hotspot blocks UDP broadcast, discovery falls back to the gateway IP or the manual IP field.
- Next ideas: reconnect tokens, streak bonus, true/false questions, CSV/Excel quiz import, sound, results export.
